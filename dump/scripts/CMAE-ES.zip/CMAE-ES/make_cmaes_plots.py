from pathlib import Path
import matplotlib

matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

outputDir = Path('output') if Path('output').exists() else Path('cma-es_output')
plotsDir = Path('plots')
runPattern = 'cmaes_hvac_full_*'
parameterSpecs = [('Crr', 0.01, 0.006, 0.02), ('Cd', 0.7, 0.6, 0.8), ('P_aux_kW', 2.0, 2.0, 2.0),
                  ('P_hvac_kW_per_C', 0.2, 0.0, 1.0), ('eta_bus', 0.82, 0.63, 0.9), ('eta_battery', 0.9, 0.63, 0.9),
                  ('eta_recup', 0.82, 0.64, 0.82)]
parameters = [item[0] for item in parameterSpecs]


def getAvailableParameterSpecs(runSummary):
    return [spec for spec in parameterSpecs if spec[0] in runSummary.columns]


def getRunLabel(folderPath):
    return folderPath.name.rsplit('_', 1)[-1]


def savePlot(name):
    plt.tight_layout()
    plt.savefig(plotsDir / name, dpi=240, bbox_inches='tight')
    plt.close()


def getTripMetrics(folderPath):
    tripMetrics = pd.read_csv(folderPath / 'cmaes_global_trip_metrics.csv')
    if 'status' in tripMetrics.columns:
        tripMetrics = tripMetrics[tripMetrics['status'].isna()].copy()
    return tripMetrics


def getRuns():
    runFolders = sorted((folderPath for folderPath in outputDir.glob(runPattern) if
                         folderPath.is_dir() and (folderPath / 'cmaes_global_convergence.csv').exists() and (
                                     folderPath / 'cmaes_global_best_parameters.csv').exists() and (
                                     folderPath / 'cmaes_global_trip_metrics.csv').exists()))
    if not runFolders:
        raise FileNotFoundError('No complete CMA-ES output folders found.')
    rows = []
    for folderPath in runFolders:
        learningCurve = pd.read_csv(folderPath / 'cmaes_global_convergence.csv')
        parameterTable = pd.read_csv(folderPath / 'cmaes_global_best_parameters.csv')
        tripMetrics = getTripMetrics(folderPath)
        lastIteration = learningCurve.iloc[-1]
        measuredEnergy = tripMetrics['measured_energy_kWh_from_power']
        predictedEnergy = tripMetrics['predicted_energy_kWh_from_power']
        energyError = predictedEnergy - measuredEnergy
        totalSquares = float(((measuredEnergy - measuredEnergy.mean()) ** 2).sum())
        residualSquares = float((energyError ** 2).sum())
        energyRSquared = 1.0 - residualSquares / totalSquares if totalSquares > 1e-12 else np.nan
        row = {'run': folderPath.name, 'run_id': getRunLabel(folderPath),
               'final_objective': float(lastIteration['best_objective']), 'iterations': int(lastIteration['iteration']),
               'n_eval_files': len(tripMetrics), 'mean_rmse_kW': tripMetrics['sample_rmse_kW'].mean(),
               'median_rmse_kW': tripMetrics['sample_rmse_kW'].median(),
               'mean_abs_energy_error_pct': tripMetrics['trip_energy_error_pct'].abs().mean(),
               'median_abs_energy_error_pct': tripMetrics['trip_energy_error_pct'].abs().median(),
               'mean_abs_energy_error_kWh': tripMetrics['trip_energy_error_kWh'].abs().mean(),
               'median_abs_energy_error_kWh': tripMetrics['trip_energy_error_kWh'].abs().median(),
               'total_measured_energy_kWh': measuredEnergy.sum(), 'total_predicted_energy_kWh': predictedEnergy.sum(),
               'total_energy_error_pct': 100.0 * energyError.sum() / max(abs(measuredEnergy.sum()), 1e-09),
               'energy_r2': energyRSquared}
        for _, item in parameterTable.iterrows():
            row[item['parameter']] = item['best_estimate']
        rows.append(row)
    runSummary = pd.DataFrame(rows).sort_values('final_objective').reset_index(drop=True)
    runSummary.to_csv(plotsDir / 'cmaes_runs_summary.csv', index=False)
    return (runFolders, runSummary)


def plotConvergence(runFolders):
    figure, axis = plt.subplots(figsize=(9.0, 5.0))
    for folderPath in runFolders:
        learningCurve = pd.read_csv(folderPath / 'cmaes_global_convergence.csv')
        axis.plot(learningCurve['iteration'], learningCurve['best_objective'] / 1000000000.0, lw=2.0,
                  label=f'run {getRunLabel(folderPath)}')
    axis.set_title('CMA-ES convergence across random seeds')
    axis.set_xlabel('Iteration')
    axis.set_ylabel('Best objective (x1e9)')
    axis.grid(True, alpha=0.3)
    axis.legend(fontsize=8)
    savePlot('01_cmaes_convergence.png')


def plotParameterChange(runSummary):
    best = runSummary.iloc[0]
    activeSpecs = getAvailableParameterSpecs(runSummary)
    activeParameters = [item[0] for item in activeSpecs]
    xValues = np.arange(len(activeSpecs))
    defaults = np.array([item[1] for item in activeSpecs], dtype=float)
    lows = np.array([item[2] for item in activeSpecs], dtype=float)
    highs = np.array([item[3] for item in activeSpecs], dtype=float)
    bestValues = np.array([best[item[0]] for item in activeSpecs], dtype=float)
    figure, axis = plt.subplots(figsize=(10.2, 5.4))
    axis.bar(xValues - 0.18, defaults, width=0.34, color='#9ecae1', label='Default / nominal')
    axis.bar(xValues + 0.18, bestValues, width=0.34, color='#1f77b4', label='CMA-ES optimized')
    axis.errorbar(xValues, (lows + highs) / 2, yerr=[(highs - lows) / 2, (highs - lows) / 2], fmt='none',
                  ecolor='black', elinewidth=2, capsize=5, label='Allowed bounds')
    axis.set_xticks(xValues)
    axis.set_xticklabels(activeParameters)
    axis.set_title('Physical parameter estimates: default vs optimized')
    axis.set_ylabel('Parameter value')
    axis.grid(axis='y', alpha=0.3)
    axis.legend()
    savePlot('02_parameters_default_vs_optimized.png')


def plotParameterStability(runSummary):
    activeSpecs = getAvailableParameterSpecs(runSummary)
    columnCount = 3
    rowCount = int(np.ceil(len(activeSpecs) / columnCount))
    figure, axes = plt.subplots(rowCount, columnCount, figsize=(12.5, 3.2 * rowCount))
    axes = axes.ravel()
    for axis, (param, defaultValue, low, high) in zip(axes, activeSpecs):
        values = runSummary[param].to_numpy(dtype=float)
        axis.hlines(0, low, high, color='black', lw=4, alpha=0.55, label='bounds')
        axis.scatter(values, np.zeros_like(values), s=80, color='#1f77b4', edgecolor='white', zorder=3)
        axis.scatter([runSummary.iloc[0][param]], [0], s=135, color='#d62728', edgecolor='white', zorder=4,
                     label='best')
        axis.axvline(defaultValue, color='#ff7f0e', lw=2, ls='--', label='default')
        axis.set_title(param)
        axis.set_yticks([])
        axis.set_xlabel('value')
        pad = 0.12 * (high - low) if high > low else max(abs(defaultValue) * 0.1, 0.1)
        axis.set_xlim(low - pad, high + pad)
        axis.grid(axis='x', alpha=0.25)
    for axis in axes[len(activeSpecs):]:
        axis.axis('off')
    handles, labels = axes[0].get_legend_handles_labels()
    figure.legend(handles, labels, loc='lower center', ncol=3, frameon=False)
    figure.suptitle('Parameter stability across seeds relative to physical bounds', y=0.98)
    savePlot('03_parameter_seed_variability_with_bounds.png')


def plotEnergyFit(bestRunFolder, runSummary):
    tripMetrics = getTripMetrics(bestRunFolder)
    measuredEnergy = tripMetrics['measured_energy_kWh_from_power']
    predictedEnergy = tripMetrics['predicted_energy_kWh_from_power']
    limit = float(max(measuredEnergy.max(), predictedEnergy.max()))
    best = runSummary.iloc[0]
    figure, axis = plt.subplots(figsize=(6.8, 6.2))
    axis.scatter(measuredEnergy, predictedEnergy, s=13, alpha=0.45, color='#1f77b4', edgecolors='none')
    axis.plot([0, limit], [0, limit], color='black', lw=1.5, ls='--', label='perfect prediction')
    axis.set_xlim(0, limit * 1.03)
    axis.set_ylim(0, limit * 1.03)
    axis.set_title('Trip energy estimation: measured vs predicted')
    axis.set_xlabel('Measured trip energy (kWh)')
    axis.set_ylabel('Predicted trip energy (kWh)')
    axis.text(0.03, 0.94,
              f"Energy R² = {best['energy_r2']:.3f}\nMean abs error = {best['mean_abs_energy_error_pct']:.1f}%",
              transform=axis.transAxes, va='top', bbox={'facecolor': 'white', 'edgecolor': '#cccccc', 'alpha': 0.9})
    axis.grid(True, alpha=0.3)
    axis.legend(loc='lower right')
    savePlot('04_energy_measured_vs_predicted.png')


def plotEnergyErrors(bestRunFolder):
    tripMetrics = getTripMetrics(bestRunFolder)
    absPct = tripMetrics['trip_energy_error_pct'].abs().clip(upper=100)
    signedPct = tripMetrics['trip_energy_error_pct'].clip(lower=-100, upper=100)
    figure, axes = plt.subplots(1, 2, figsize=(12.2, 4.8))
    axes[0].hist(absPct, bins=36, color='#2ca02c', alpha=0.82)
    axes[0].axvline(absPct.mean(), color='black', lw=2, label=f'mean {absPct.mean():.1f}%')
    axes[0].axvline(absPct.median(), color='#d62728', lw=2, ls='--', label=f'median {absPct.median():.1f}%')
    axes[0].set_title('Absolute trip energy error')
    axes[0].set_xlabel('Absolute energy error (%)')
    axes[0].set_ylabel('Number of trips/files')
    axes[0].legend()
    axes[1].hist(signedPct, bins=40, color='#1f77b4', alpha=0.82)
    axes[1].axvline(0, color='black', lw=1.5)
    axes[1].axvline(signedPct.mean(), color='#d62728', lw=2, label=f'mean {signedPct.mean():.1f}%')
    axes[1].set_title('Signed trip energy error')
    axes[1].set_xlabel('Energy error (%)')
    axes[1].set_ylabel('Number of trips/files')
    axes[1].legend()
    for axis in axes:
        axis.grid(axis='y', alpha=0.3)
    savePlot('05_energy_error_statistics.png')


def plotRunAccuracy(runSummary):
    ordered = runSummary.sort_values('final_objective').reset_index(drop=True)
    labels = [f'run {value}' for value in ordered['run_id']]
    figure, axes = plt.subplots(1, 3, figsize=(13.4, 4.5))
    color = ['#d62728'] + ['#9ecae1'] * (len(ordered) - 1)
    axes[0].bar(labels, ordered['final_objective'] / 1000000000.0, color=color)
    axes[0].set_title('Final objective')
    axes[0].set_ylabel('Objective (x1e9)')
    axes[1].bar(labels, ordered['mean_rmse_kW'], color=color)
    axes[1].set_title('Mean sample RMSE')
    axes[1].set_ylabel('RMSE (kW)')
    axes[2].bar(labels, ordered['mean_abs_energy_error_pct'], color=color)
    axes[2].set_title('Mean absolute energy error')
    axes[2].set_ylabel('Error (%)')
    for axis in axes:
        axis.tick_params(axis='x', rotation=45)
        axis.grid(axis='y', alpha=0.3)
    savePlot('06_model_accuracy_across_seeds.png')


def plotTotalEnergy(bestRunFolder):
    tripMetrics = getTripMetrics(bestRunFolder)
    measuredTotal = tripMetrics['measured_energy_kWh_from_power'].sum()
    predictedTotal = tripMetrics['predicted_energy_kWh_from_power'].sum()
    errorPct = 100.0 * (predictedTotal - measuredTotal) / max(abs(measuredTotal), 1e-09)
    figure, axis = plt.subplots(figsize=(6.8, 4.8))
    bars = axis.bar(['Measured total', 'Predicted total'], [measuredTotal, predictedTotal],
                    color=['#1f77b4', '#d62728'])
    axis.set_title('Total dataset energy: measured vs predicted')
    axis.set_ylabel('Energy (kWh)')
    axis.grid(axis='y', alpha=0.3)
    axis.text(0.5, 0.93, f'Total energy error = {errorPct:.2f}%', transform=axis.transAxes, ha='center', va='top',
              bbox={'facecolor': 'white', 'edgecolor': '#cccccc', 'alpha': 0.9})
    for bar in bars:
        height = bar.get_height()
        axis.text(bar.get_x() + bar.get_width() / 2, height, f'{height:,.0f}', ha='center', va='bottom', fontsize=9)
    savePlot('07_total_energy_measured_vs_predicted.png')


def plotEnergyErrorByTripEnergy(bestRunFolder):
    tripMetrics = getTripMetrics(bestRunFolder)
    xValues = tripMetrics['measured_energy_kWh_from_power']
    yValues = tripMetrics['trip_energy_error_pct'].clip(lower=-100, upper=100)
    figure, axis = plt.subplots(figsize=(8.4, 4.8))
    axis.scatter(xValues, yValues, s=13, alpha=0.42, color='#1f77b4', edgecolors='none')
    axis.axhline(0, color='black', lw=1.4)
    axis.axhline(10, color='#ff7f0e', lw=1.1, ls='--')
    axis.axhline(-10, color='#ff7f0e', lw=1.1, ls='--')
    axis.set_title('Energy error versus trip energy')
    axis.set_xlabel('Measured trip energy (kWh)')
    axis.set_ylabel('Energy error (%)')
    axis.grid(True, alpha=0.3)
    savePlot('08_energy_error_vs_trip_energy.png')


def plotHvacLoadCurve(runSummary):
    best = runSummary.iloc[0]
    hvacCoef = float(best['P_hvac_kW_per_C'])
    ambientTemperature = np.linspace(-10.0, 40.0, 151)
    hvacPower = hvacCoef * np.abs(ambientTemperature - 20.0)
    figure, axis = plt.subplots(figsize=(7.4, 4.8))
    axis.plot(ambientTemperature, hvacPower, color='#1f77b4', lw=2.8)
    axis.axvline(20.0, color='black', lw=1.4, ls='--', label='20 C cabin setpoint')
    axis.set_title('Estimated HVAC load from ambient temperature')
    axis.set_xlabel('Ambient temperature (C)')
    axis.set_ylabel('HVAC power before battery losses (kW)')
    axis.text(0.03, 0.94, f'HVAC coefficient = {hvacCoef:.3f} kW/C\nP_aux fixed = 2.0 kW', transform=axis.transAxes,
              va='top', bbox={'facecolor': 'white', 'edgecolor': '#cccccc', 'alpha': 0.9})
    axis.grid(True, alpha=0.3)
    axis.legend(loc='upper center')
    savePlot('09_hvac_temperature_load_curve.png')


def main():
    plotsDir.mkdir(parents=True, exist_ok=True)
    runFolders, runSummary = getRuns()
    bestRunFolder = outputDir / runSummary.iloc[0]['run']
    plotConvergence(runFolders)
    plotParameterChange(runSummary)
    plotParameterStability(runSummary)
    plotEnergyFit(bestRunFolder, runSummary)
    plotEnergyErrors(bestRunFolder)
    plotRunAccuracy(runSummary)
    plotTotalEnergy(bestRunFolder)
    plotEnergyErrorByTripEnergy(bestRunFolder)
    plotHvacLoadCurve(runSummary)
    print(f'Created project-focused plots in {plotsDir.resolve()}')
    print(f'Best run: {bestRunFolder.name}')


if __name__ == '__main__':
    main()
