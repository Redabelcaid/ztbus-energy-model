import argparse
import multiprocessing as mp
import os

import numpy as np
import pandas as pd

TIME_COL = "time_iso"
SPEED_COL = "odometry_vehicleSpeed"
POWER_COL = "electric_powerDemand"
ALTITUDE_COL = "gnss_altitude"
TEMP_COL = "temperature_ambient"
PASSENGER_COL = "itcs_numberOfPassengers"
TRIP_GAP_THRESHOLD_SEC = 5 * 60

CURB_MASS_KG = 19000.0
PASSENGER_MASS_KG = 68.0
DEFAULT_PASSENGERS = 0.0

PARAMETER_SPECS = [
    {"name": "Crr", "default": 0.010, "lb": 0.006, "ub": 0.020},
    {"name": "Cd", "default": 0.700, "lb": 0.600, "ub": 0.800},
    {"name": "P_aux_kW", "default": 2.000, "lb": 2.000, "ub": 2.000},
    {"name": "P_hvac_kW_per_C", "default": 0.200, "lb": 0.000, "ub": 1.000},
    {"name": "eta_bus", "default": 0.820, "lb": 0.630, "ub": 0.900},
    {"name": "eta_battery", "default": 0.900, "lb": 0.630, "ub": 0.900},
    {"name": "eta_recup", "default": 0.820, "lb": 0.640, "ub": 0.820},
]

A_FRONT = 8.4
RHO_AIR = 1.2
G = 9.81
MIN_RECUP_SPEED_KMH = 15.0
GRADE_CLIP = 0.08
CABIN_SETPOINT_C = 20.0


class TeeLogger:
    def __init__(self, filePath):
        self.filePath = filePath
        self.logFile = None

    def __enter__(self):
        self.logFile = open(self.filePath, "w", encoding="utf-8")
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if self.logFile is not None:
            self.logFile.close()

    def print(self, *args, **kwargs):
        kwargs.setdefault("flush", True)
        print(*args, **kwargs)
        if self.logFile is not None:
            print(*args, **kwargs, file=self.logFile)
            self.logFile.flush()


def getInputFiles(inputPath):
    if os.path.isdir(inputPath):
        cleanedFiles = sorted(
            os.path.join(root, name)
            for root, _, files in os.walk(inputPath)
            for name in files
            if name.lower().endswith("_cleaned.csv"))
        csvFiles = cleanedFiles or sorted(
            os.path.join(root, name)
            for root, _, files in os.walk(inputPath)
            for name in files
            if (
                    name.lower().endswith(".csv")
                    and not name.lower().endswith("_summary.csv")
                    and not name.lower().endswith("_preview.csv")))
        parquetFiles = sorted(
            os.path.join(root, name)
            for root, _, files in os.walk(inputPath)
            for name in files
            if name.lower().endswith(".parquet"))
        inputFiles = cleanedFiles or csvFiles or parquetFiles
    else:
        inputFiles = [inputPath]

    if not inputFiles:
        raise FileNotFoundError(f"No CSV or parquet files found in {inputPath!r}")

    return inputFiles


def getInputFrame(filePath):
    extension = os.path.splitext(filePath)[1].lower()
    if extension == ".csv":
        return pd.read_csv(filePath)
    if extension == ".parquet":
        return pd.read_parquet(filePath)
    raise ValueError(f"Unsupported input file type: {filePath}")


def getExistingColumn(df, candidates):
    for column in candidates:
        if column in df.columns:
            return column
    return None


def getNumericColumn(df, candidates, defaultValues=None):
    column = getExistingColumn(df, candidates)
    if column is None:
        if defaultValues is None:
            raise ValueError(f"Missing one of required columns: {candidates}")
        return pd.Series(defaultValues, index=df.index, dtype=float)
    return pd.to_numeric(df[column], errors="coerce")


def getModelFrame(rawFrame, sourceFile):
    df = rawFrame.copy()
    df["source_file"] = sourceFile

    if "time_s" in df.columns:
        df["time_s"] = pd.to_numeric(df["time_s"], errors="coerce")
    elif TIME_COL in df.columns:
        df["time"] = pd.to_datetime(df[TIME_COL], errors="coerce", utc=True)
        df["time_s"] = (df["time"] - df["time"].min()).dt.total_seconds()
    elif "time_unix" in df.columns:
        df["time_s"] = pd.to_numeric(df["time_unix"], errors="coerce")
        df["time_s"] = df["time_s"] - df["time_s"].min()
    elif "time" in df.columns:
        numericTime = pd.to_numeric(df["time"], errors="coerce")
        if numericTime.notna().sum() >= len(df) * 0.5:
            df["time_s"] = numericTime - numericTime.min()
        else:
            parsedTime = pd.to_datetime(df["time"], errors="coerce", utc=True)
            df["time_s"] = (parsedTime - parsedTime.min()).dt.total_seconds()
    elif isinstance(df.index, pd.DatetimeIndex):
        parsedTime = pd.to_datetime(df.index, errors="coerce", utc=True)
        df["time_s"] = (parsedTime - parsedTime.min()).total_seconds()
    else:
        raise ValueError("Missing time column. Expected time_s, time_iso, or time_unix.")

    df = df.dropna(subset=["time_s"]).sort_values("time_s").reset_index(drop=True)
    df["dt"] = df["time_s"].diff()
    df["dt"] = df["dt"].where(df["dt"] > 0.0, np.nan)

    if "trip_id" not in df.columns:
        df["time_gap"] = df["time_s"].diff()
        df["trip_number"] = (df["time_gap"] > TRIP_GAP_THRESHOLD_SEC).cumsum().astype(int)
        df["trip_id"] = df["source_file"].astype(str) + "_trip_" + df["trip_number"].astype(str)

    df["time_s"] = df.groupby("trip_id")["time_s"].transform(lambda x: x - x.min())
    df["dt"] = df.groupby("trip_id")["time_s"].diff()
    df["speed_m_per_s"] = getNumericColumn(df, ["speed_m_per_s", SPEED_COL])

    if getExistingColumn(df, ["acceleration_m_s2", "accel_mps2"]) is not None:
        df["acceleration_m_s2"] = getNumericColumn(df, ["acceleration_m_s2", "accel_mps2"])
    else:
        df["acceleration_m_s2"] = df.groupby("trip_id")["speed_m_per_s"].diff() / df["dt"]

    if getExistingColumn(df, ["distance_m", "distance_cum_m"]) is not None:
        df["distance_m"] = getNumericColumn(df, ["distance_m", "distance_cum_m"])
    else:
        df["distance_step_m"] = df["speed_m_per_s"] * df["dt"].fillna(0.0)
        df["distance_m"] = df.groupby("trip_id")["distance_step_m"].cumsum()

    df["elevation_m"] = getNumericColumn(df, ["elevation_m", ALTITUDE_COL], defaultValues=0.0)

    if getExistingColumn(df, ["temperature_C", "temperature_ambient_C"]) is not None:
        df["temperature_C"] = getNumericColumn(df, ["temperature_C", "temperature_ambient_C"])
    elif TEMP_COL in df.columns:
        temp = pd.to_numeric(df[TEMP_COL], errors="coerce")
        df["temperature_C"] = np.where(temp > 100.0, temp - 273.15, temp)
    else:
        df["temperature_C"] = 21.0

    if "mass_kg" in df.columns:
        df["mass_kg"] = pd.to_numeric(df["mass_kg"], errors="coerce")
    elif "estimated_vehicle_mass_kg" in df.columns:
        df["mass_kg"] = pd.to_numeric(df["estimated_vehicle_mass_kg"], errors="coerce")
    else:
        passengers = getNumericColumn(df, [PASSENGER_COL, "passengers"], defaultValues=DEFAULT_PASSENGERS)
        df["mass_kg"] = CURB_MASS_KG + PASSENGER_MASS_KG * passengers.fillna(DEFAULT_PASSENGERS)

    if "power_kW" in df.columns:
        df["power_kW"] = pd.to_numeric(df["power_kW"], errors="coerce")
    else:
        df["power_kW"] = getNumericColumn(df, [POWER_COL, "power_measured_W"]) / 1000.0

    keep = [
        "trip_id",
        "time_s",
        "dt",
        "distance_m",
        "speed_m_per_s",
        "acceleration_m_s2",
        "elevation_m",
        "temperature_C",
        "mass_kg",
        "power_kW",
        "source_file",
    ]
    df = df[[column for column in keep if column in df.columns]].copy()
    df = df.dropna(
        subset=[
            "trip_id",
            "time_s",
            "distance_m",
            "speed_m_per_s",
            "acceleration_m_s2",
            "elevation_m",
            "mass_kg",
            "power_kW",
        ])
    df = df[df["dt"].fillna(0.0) > 0.0].copy()
    return df.sort_values(["trip_id", "time_s"]).reset_index(drop=True)


def getBoundsArrays():
    lowerBounds = np.array([spec["lb"] for spec in PARAMETER_SPECS], dtype=float)
    upperBounds = np.array([spec["ub"] for spec in PARAMETER_SPECS], dtype=float)
    defaultValues = np.array([spec["default"] for spec in PARAMETER_SPECS], dtype=float)
    return lowerBounds, upperBounds, defaultValues


def getParamsFromTheta(theta):
    params = {
        spec["name"]: float(theta[index])
        for index, spec in enumerate(PARAMETER_SPECS)
    }
    params["A_front"] = A_FRONT
    params["rho_air"] = RHO_AIR
    params["g"] = G
    params["min_recup_speed_kmh"] = MIN_RECUP_SPEED_KMH
    return params


def getParameterTable(theta):
    rows = []
    for index, spec in enumerate(PARAMETER_SPECS):
        rows.append(
            {
                "parameter": spec["name"],
                "default": spec["default"],
                "lower_bound": spec["lb"],
                "upper_bound": spec["ub"],
                "best_estimate": float(theta[index]),
            })
    return pd.DataFrame(rows)


def getFiniteArray(values, fillValue=0.0):
    array = np.asarray(values, dtype=float)
    series = pd.Series(array).replace([np.inf, -np.inf], np.nan)
    series = series.interpolate(limit_direction="both").fillna(fillValue)
    return series.to_numpy(dtype=float)


def getTimeStep(timeS):
    t = getFiniteArray(timeS)
    if len(t) == 0:
        return np.array([], dtype=float)
    if len(t) == 1:
        return np.array([1.0], dtype=float)
    dt = np.diff(t, prepend=t[0])
    dt[0] = dt[1] if len(dt) > 1 else 1.0
    dt = np.where(np.isfinite(dt), dt, 1.0)
    dt = np.where(dt > 0.0, dt, 1.0)
    return np.clip(dt, 1e-3, 10.0)


def getGradient(values):
    x = getFiniteArray(values)
    grad = np.zeros_like(x)
    n = len(x)
    if n <= 1:
        return grad
    grad[0] = x[1] - x[0]
    grad[-1] = x[-1] - x[-2]
    if n > 2:
        grad[1:-1] = (x[2:] - x[:-2]) / 2.0
    return grad


def getPredictionArrays(df, theta):
    params = getParamsFromTheta(theta)
    v = getFiniteArray(df["speed_m_per_s"])
    a = getFiniteArray(df["acceleration_m_s2"])
    distance = getFiniteArray(df["distance_m"])
    elevation = getFiniteArray(df["elevation_m"])
    mass = getFiniteArray(df["mass_kg"], fillValue=CURB_MASS_KG)
    temperature = getFiniteArray(df["temperature_C"], fillValue=CABIN_SETPOINT_C)
    timeS = getFiniteArray(df["time_s"])
    dt = getTimeStep(timeS)

    distanceGradient = getGradient(distance)
    elevationGradient = getGradient(elevation)
    grade = np.zeros_like(distance)
    isValidDistance = np.abs(distanceGradient) > 1e-6
    grade[isValidDistance] = elevationGradient[isValidDistance] / distanceGradient[isValidDistance]
    grade = np.clip(np.where(np.isfinite(grade), grade, 0.0), -GRADE_CLIP, GRADE_CLIP)
    slopeAngle = np.arctan(grade)

    rollForce = mass * params["g"] * params["Crr"] * np.cos(slopeAngle)
    aeroForce = 0.5 * params["rho_air"] * v ** 2 * params["A_front"] * params["Cd"]
    inertiaForce = mass * a
    gradeForce = mass * params["g"] * np.sin(slopeAngle)
    totalForce = rollForce + aeroForce + inertiaForce + gradeForce

    loadPower = v * totalForce
    propulsionPower = np.where(loadPower >= 0.0, loadPower / max(params["eta_bus"], 1e-6), loadPower)
    minRecupSpeed = params["min_recup_speed_kmh"] / 3.6
    isRecupAllowed = (propulsionPower < 0.0) & (v >= minRecupSpeed)
    isLowSpeedRecupBlocked = (propulsionPower < 0.0) & (v < minRecupSpeed)
    propulsionPower = np.where(isRecupAllowed, propulsionPower * params["eta_recup"], propulsionPower)
    propulsionPower = np.where(isLowSpeedRecupBlocked, 0.0, propulsionPower)

    auxPower = np.full(len(df), params["P_aux_kW"] * 1000.0, dtype=float)
    hvacPower = params["P_hvac_kW_per_C"] * np.abs(temperature - CABIN_SETPOINT_C) * 1000.0
    modelPower = propulsionPower + (auxPower + hvacPower) / max(params["eta_battery"], 1e-6)

    return {
        "dt": dt,
        "power_model_W": modelPower,
        "power_measured_W": getFiniteArray(df["power_kW"]) * 1000.0,
    }


def getFileLoss(
        theta,
        filePath,
        inputRoot,
        powerWeight,
        energyWeight,
        verbose=False, ):
    sourceFile = os.path.relpath(filePath, inputRoot) if os.path.isdir(inputRoot) else os.path.basename(filePath)
    try:
        rawFrame = getInputFrame(filePath)
        df = getModelFrame(rawFrame, sourceFile)
    except Exception as exc:
        if verbose:
            print(f"Skipping {sourceFile}: {exc}", flush=True)
        return 0.0, 0
    if df.empty:
        return 0.0, 0

    weightedLossSum = 0.0
    tripCount = 0
    for _, trip in df.groupby("trip_id", sort=False):
        arrays = getPredictionArrays(trip, theta)
        y = arrays["power_measured_W"]
        yhat = arrays["power_model_W"]
        dt = arrays["dt"]
        powerMseWatts = float(np.mean((yhat - y) ** 2))
        measuredEnergy = float(np.sum((y / 1000.0) * dt / 3600.0))
        predictedEnergy = float(np.sum((yhat / 1000.0) * dt / 3600.0))
        energyRelativeError = ((predictedEnergy - measuredEnergy) / max(abs(measuredEnergy), 1e-6)) ** 2
        loss = powerWeight * powerMseWatts + energyWeight * energyRelativeError * 1e8
        if np.isfinite(loss):
            weightedLossSum += loss
            tripCount += 1

    return weightedLossSum, tripCount


def getMonthGroupKey(filePath, inputRoot):
    relativePath = os.path.relpath(filePath, inputRoot) if os.path.isdir(inputRoot) else os.path.basename(filePath)
    parts = relativePath.split(os.sep)
    for index, part in enumerate(parts):
        if part.startswith("month="):
            return os.path.join(*parts[:index + 1])
    return os.path.dirname(relativePath) or "."


def getBalancedMonthChunks(filePaths, inputRoot, workers):
    grouped = {}
    for filePath in filePaths:
        grouped.setdefault(getMonthGroupKey(filePath, inputRoot), []).append(filePath)

    chunkCount = max(1, min(int(workers), len(grouped)))
    chunks = [[] for _ in range(chunkCount)]
    chunkSizes = [0 for _ in range(chunkCount)]

    for _, groupFiles in sorted(grouped.items(), key=lambda item: len(item[1]), reverse=True):
        target = int(np.argmin(chunkSizes))
        chunks[target].extend(groupFiles)
        chunkSizes[target] += len(groupFiles)

    return [chunk for chunk in chunks if chunk]


def getChunkLoss(args):
    theta, fileChunk, inputRoot, powerWeight, energyWeight = args
    totalLoss = 0.0
    totalCount = 0
    for filePath in fileChunk:
        lossSum, count = getFileLoss(theta, filePath, inputRoot, powerWeight, energyWeight, verbose=False)
        totalLoss += lossSum
        totalCount += count
    return totalLoss, totalCount


def getObjectiveFromTheta(
        theta,
        filePaths,
        inputRoot,
        powerWeight,
        energyWeight,
        pool=None,
        fileChunks=None, ):
    totalLoss = 0.0
    totalCount = 0
    if pool is None or fileChunks is None:
        for filePath in filePaths:
            lossSum, count = getFileLoss(theta, filePath, inputRoot, powerWeight, energyWeight, verbose=True)
            totalLoss += lossSum
            totalCount += count
    else:
        workItems = [
            (theta, fileChunk, inputRoot, powerWeight, energyWeight)
            for fileChunk in fileChunks
        ]
        for lossSum, count in pool.map(getChunkLoss, workItems):
            totalLoss += lossSum
            totalCount += count
    if totalCount == 0:
        return 1e30
    return float(totalLoss / totalCount)


def runBoundedCmaes(
        filePaths,
        inputRoot,
        iterations,
        populationSize,
        sigma,
        seed,
        powerWeight,
        energyWeight,
        workers,
        logger, ):
    rng = np.random.default_rng(seed)
    lowerBounds, upperBounds, defaultValues = getBoundsArrays()
    boundsSpan = upperBounds - lowerBounds
    scaledSpan = np.where(boundsSpan > 0.0, boundsSpan, 1.0)
    dim = len(defaultValues)

    if populationSize is None:
        populationSize = 4 + int(3 * np.log(dim))
    populationSize = max(4, int(populationSize))
    mu = populationSize // 2

    weights = np.log(mu + 0.5) - np.log(np.arange(1, mu + 1))
    weights = weights / np.sum(weights)
    muEff = 1.0 / np.sum(weights ** 2)

    cSigma = (muEff + 2.0) / (dim + muEff + 5.0)
    dSigma = 1.0 + 2.0 * max(0.0, np.sqrt((muEff - 1.0) / (dim + 1.0)) - 1.0) + cSigma
    cC = (4.0 + muEff / dim) / (dim + 4.0 + 2.0 * muEff / dim)
    c1 = 2.0 / ((dim + 1.3) ** 2 + muEff)
    cMu = min(
        1.0 - c1,
        2.0 * (muEff - 2.0 + 1.0 / muEff) / ((dim + 2.0) ** 2 + muEff), )
    chiN = np.sqrt(dim) * (1.0 - 1.0 / (4.0 * dim) + 1.0 / (21.0 * dim ** 2))

    meanScaled = (defaultValues - lowerBounds) / scaledSpan
    sigmaScaled = float(sigma)
    covariance = np.eye(dim)
    pathSigma = np.zeros(dim)
    pathCovariance = np.zeros(dim)

    workers = max(1, int(workers))
    fileChunks = getBalancedMonthChunks(filePaths, inputRoot, workers)

    bestTheta = np.clip(defaultValues.copy(), lowerBounds, upperBounds)
    history = []
    logPrint = logger.print if logger is not None else print
    logPrint(f"Using {workers} worker process(es) across {len(fileChunks)} balanced month/file chunk(s).")
    logPrint("Starting worker pool." if workers > 1 else "Running without a worker pool.")
    pool = mp.Pool(processes=workers) if workers > 1 else None
    logPrint("Worker pool is ready." if pool is not None else "Single-process mode is ready.")

    try:
        logPrint("Evaluating initial parameter set.")
        bestLoss = getObjectiveFromTheta(
            bestTheta,
            filePaths,
            inputRoot,
            powerWeight,
            energyWeight,
            pool=pool,
            fileChunks=fileChunks if pool is not None else None, )

        for iteration in range(1, iterations + 1):
            covariance = (covariance + covariance.T) / 2.0
            eigenvalues, eigenvectors = np.linalg.eigh(covariance)
            eigenvalues = np.maximum(eigenvalues, 1e-12)
            sqrtCovariance = eigenvectors @ np.diag(np.sqrt(eigenvalues)) @ eigenvectors.T
            invSqrtCovariance = eigenvectors @ np.diag(1.0 / np.sqrt(eigenvalues)) @ eigenvectors.T

            zSamples = rng.normal(size=(populationSize, dim))
            ySamples = zSamples @ sqrtCovariance.T
            scaledSamples = meanScaled + sigmaScaled * ySamples
            scaledSamples = np.clip(scaledSamples, 0.0, 1.0)
            thetaSamples = lowerBounds + scaledSamples * boundsSpan
            losses = np.array(
                [
                    getObjectiveFromTheta(
                        theta,
                        filePaths,
                        inputRoot,
                        powerWeight,
                        energyWeight,
                        pool=pool,
                        fileChunks=fileChunks if pool is not None else None, )
                    for theta in thetaSamples
                ],
                dtype=float, )

            order = np.argsort(losses)
            thetaSamples = thetaSamples[order]
            scaledSamples = scaledSamples[order]
            ySamples = ySamples[order]
            losses = losses[order]

            if losses[0] < bestLoss:
                bestLoss = float(losses[0])
                bestTheta = thetaSamples[0].copy()

            oldMeanScaled = meanScaled.copy()
            selectedSamples = scaledSamples[:mu]
            meanScaled = np.sum(selectedSamples * weights[:, None], axis=0)
            weightedStep = (meanScaled - oldMeanScaled) / max(sigmaScaled, 1e-12)

            pathSigma = (1.0 - cSigma) * pathSigma + np.sqrt(cSigma * (2.0 - cSigma) * muEff) * (
                    invSqrtCovariance @ weightedStep)
            pathSigmaNorm = np.linalg.norm(pathSigma)
            smallStepLimit = (1.4 + 2.0 / (dim + 1.0)) * chiN
            isSmallStep = float(pathSigmaNorm / np.sqrt(1.0 - (1.0 - cSigma) ** (2.0 * iteration)) < smallStepLimit)

            pathCovariance = (1.0 - cC) * pathCovariance + isSmallStep * np.sqrt(cC * (2.0 - cC) * muEff) * weightedStep
            rankMu = np.zeros((dim, dim))
            for weight, y in zip(weights, ySamples[:mu]):
                rankMu += weight * np.outer(y, y)

            covariance = (
                    (1.0 - c1 - cMu) * covariance
                    + c1 * (np.outer(pathCovariance, pathCovariance) + (1.0 - isSmallStep) * cC * (
                        2.0 - cC) * covariance)
                    + cMu * rankMu)
            sigmaScaled *= np.exp((cSigma / dSigma) * (pathSigmaNorm / chiN - 1.0))
            sigmaScaled = float(np.clip(sigmaScaled, 1e-4, 2.0))

            row = {"iteration": iteration, "best_objective": bestLoss, "sigma": sigmaScaled}
            row.update(getParamsFromTheta(bestTheta))
            history.append(row)

            if iteration == 1 or iteration % 10 == 0 or iteration == iterations:
                params = getParamsFromTheta(bestTheta)
                logPrint(
                    f"Iteration {iteration:4d} | "
                    f"objective={bestLoss:.6f} | "
                    f"Crr={params['Crr']:.6f} | "
                    f"Cd={params['Cd']:.6f} | "
                    f"P_aux_kW={params['P_aux_kW']:.6f} | "
                    f"P_hvac_kW_per_C={params['P_hvac_kW_per_C']:.6f} | "
                    f"eta_bus={params['eta_bus']:.6f} | "
                    f"eta_battery={params['eta_battery']:.6f} | "
                    f"eta_recup={params['eta_recup']:.6f}")
    finally:
        if pool is not None:
            pool.close()
            pool.join()

    return bestTheta, bestLoss, pd.DataFrame(history)


def getEvaluationTable(theta, filePaths, inputRoot):
    rows = []
    for filePath in filePaths:
        sourceFile = os.path.relpath(filePath, inputRoot) if os.path.isdir(inputRoot) else os.path.basename(filePath)
        try:
            rawFrame = getInputFrame(filePath)
            df = getModelFrame(rawFrame, sourceFile)
        except Exception as exc:
            rows.append(
                {
                    "trip_id": "",
                    "source_file": sourceFile,
                    "n_samples": 0,
                    "measured_energy_kWh_from_power": np.nan,
                    "predicted_energy_kWh_from_power": np.nan,
                    "trip_energy_error_kWh": np.nan,
                    "trip_energy_error_pct": np.nan,
                    "sample_mse_kW2": np.nan,
                    "sample_rmse_kW": np.nan,
                    "status": f"skipped: {exc}",
                })
            continue
        if df.empty:
            continue

        for trip_id, trip in df.groupby("trip_id", sort=False):
            arrays = getPredictionArrays(trip, theta)
            y = arrays["power_measured_W"]
            yhat = arrays["power_model_W"]
            dt = arrays["dt"]
            measuredEnergy = float(np.sum((y / 1000.0) * dt / 3600.0))
            predictedEnergy = float(np.sum((yhat / 1000.0) * dt / 3600.0))
            sampleMseKw2 = float(np.mean(((yhat - y) / 1000.0) ** 2))
            rows.append(
                {
                    "trip_id": trip_id,
                    "source_file": sourceFile,
                    "n_samples": len(trip),
                    "measured_energy_kWh_from_power": measuredEnergy,
                    "predicted_energy_kWh_from_power": predictedEnergy,
                    "trip_energy_error_kWh": predictedEnergy - measuredEnergy,
                    "trip_energy_error_pct": 100.0 * (predictedEnergy - measuredEnergy) / max(abs(measuredEnergy),
                                                                                              1e-6),
                    "sample_mse_kW2": sampleMseKw2,
                    "sample_rmse_kW": float(np.sqrt(sampleMseKw2)),
                })
    return pd.DataFrame(rows)


def getArgs():
    parser = argparse.ArgumentParser(
        description="Fit one global bus energy parameter set with parallel streaming CMA-ES.")
    parser.add_argument("dataPath", help="Top-level CSV/parquet dataset directory or one input file.")
    parser.add_argument("--iterations", type=int, default=120, help="Number of CMA-ES iterations.")
    parser.add_argument("--population-size", dest="populationSize", type=int, default=8,
                        help="Number of candidates per iteration.")
    parser.add_argument("--sigma", type=float, default=0.25, help="Initial CMA-ES step size in normalized bounds.")
    parser.add_argument("--seed", type=int, default=42, help="Random seed.")
    parser.add_argument("--power-weight", dest="powerWeight", type=float, default=0.65,
                        help="Weight for sample power MSE in watts.")
    parser.add_argument("--energy-weight", dest="energyWeight", type=float, default=0.35,
                        help="Weight for trip energy relative error.")
    parser.add_argument("--workers", type=int, default=1, help="Worker processes for parallel month/file chunks.")
    parser.add_argument("--output-dir", dest="outputDir", default=os.path.join("output", "cmaes_streaming_parallel"),
                        help="Output directory.")
    return parser.parse_args()


if __name__ == "__main__":
    args = getArgs()
    os.makedirs(args.outputDir, exist_ok=True)

    with TeeLogger(os.path.join(args.outputDir, "printed_output.txt")) as logger:
        filePaths = getInputFiles(args.dataPath)
        logger.print(f"Discovered {len(filePaths)} input file(s).")
        logger.print("Parallel streaming objective is enabled: each worker loads its assigned files one at a time.")

        bestTheta, bestObjective, convergenceTable = runBoundedCmaes(
            filePaths=filePaths,
            inputRoot=args.dataPath,
            iterations=args.iterations,
            populationSize=args.populationSize,
            sigma=args.sigma,
            seed=args.seed,
            powerWeight=args.powerWeight,
            energyWeight=args.energyWeight,
            workers=args.workers,
            logger=logger, )

        params = getParamsFromTheta(bestTheta)
        logger.print("\nEstimated global parameters:")
        for spec in PARAMETER_SPECS:
            logger.print(f"{spec['name']}: {params[spec['name']]:.6f}")
        logger.print(f"\nFinal CMA-ES objective: {bestObjective:.6f}")

        metricsTable = getEvaluationTable(bestTheta, filePaths, args.dataPath)
        logger.print("\nEvaluation summary:")
        logger.print(metricsTable.describe(include="all"))

        getParameterTable(bestTheta).to_csv(os.path.join(args.outputDir, "cmaes_global_best_parameters.csv"),
                                            index=False)
        convergenceTable.to_csv(os.path.join(args.outputDir, "cmaes_global_convergence.csv"), index=False)
        metricsTable.to_csv(os.path.join(args.outputDir, "cmaes_global_trip_metrics.csv"), index=False)
